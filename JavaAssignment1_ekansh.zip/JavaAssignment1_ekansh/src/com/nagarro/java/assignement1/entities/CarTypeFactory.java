package com.nagarro.java.assignement1.entities;
import com.nagarro.java.assignement1.entities.CarEntities;
import com.nagarro.java.assignement1.constants.Constant;

public class CarTypeFactory {

	public CarEntities getInstanceOfVehicle(String carModel, String carType, Double carCost, String insuranceType) {
		
//		CarEntities newCarEntity = new CarEntities();
//		newCarEntity.setCarModel(carModel);
//		newCarEntity.setCarType(carType);
//		newCarEntity.setCarCost(carCost);
//		newCarEntity.setInsuranceType(insuranceType);
		
		if (carType.equals(Constant.HATCHBACK)) {
			CarEntities car_instance = new HatchBack(carModel,carType,carCost,insuranceType);
			return car_instance;
		}
		else if (carType.equals(Constant.SEDAN)) {
			CarEntities car_instance = new Sedan(carModel,carType,carCost,insuranceType);
			return car_instance;
		}
		else {
			CarEntities car_instance = new Suv(carModel,carType,carCost,insuranceType);
			return car_instance;

		}

	}
}	
	
	
	
	
	
	
	
// testing this unit with main and hard coded values	
//	public static void main(String[] args) {
//		String carModel="Swift";
//		String carType ="HatchBack";
//		Double carCost =1000000.0;
//		String insuranceType = "Premium";
//		CarTypeFactory ctf = new CarTypeFactory();
//		CarEntities obj = ctf.getInstanceOfVehicle(carModel, carType, carCost, insuranceType);
//		System.out.println(obj.getCarModel());
//		System.out.println(obj.getCarType());
//		System.out.println(obj.getCarCost());
//		System.out.println(obj.getInsuranceType());
//		
//	}
//}
