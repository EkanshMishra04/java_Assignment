package com.nagarro.java.assignement1.validation;
import com.nagarro.java.assignement1.constants.*;

public class UnknownInsuranceTypeException extends Exception {
	public UnknownInsuranceTypeException(String s) {
		super(s);
	}
}
