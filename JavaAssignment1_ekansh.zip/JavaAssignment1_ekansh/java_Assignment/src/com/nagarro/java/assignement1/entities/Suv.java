package com.nagarro.java.assignement1.entities;
import com.nagarro.java.assignement1.constants.Constant;

public class Suv  extends CarEntities implements Insurance  {
	private Double price;
	private Double carTypeCost;
	private String insuranceType;
	private Double insuranceCost = 0.0;

	public Suv(String carModel, String carType, Double carCost, String insuranceType) {
		setCarModel(carModel);
		setCarType(carType);
		setCarCost(carCost);
		setInsuranceType(insuranceType);
	}

	@Override
	public Double insurance_calculator() {
		price = getCarCost();
		carTypeCost = (price * Constant.SUV_PERCENT)/ 100;
		insuranceType = getInsuranceType();

		if (insuranceType == Constant.INSURANCE_PREMIUM) {
			insuranceCost = carTypeCost + (carTypeCost * Constant.PREMIUM_PERCENT) / 100;
			return insuranceCost;
		} else {
			return carTypeCost;
		}
	}

}
//	private Double price;
//	private Double carTypeCost;
//	private String insuranceType;
//	private Double insuranceCost=0.0;
//	
//	public CarEntities obj = null;
//	
//	public Suv(CarEntities object) {
//		this.obj = object;
//	}
//	public CarEntities retObject() {
//		return this.obj;
//	}
//
//	@Override
//	public double carTypeCost() {
//		price = this.obj.getCarCost();
//		carTypeCost = (price*Constant.HATCH_BACK_PERCENT)*100;
//		return carTypeCost;
//	}
//	
//	@Override
//	public Double insurance_calculator() {
//		insuranceType = this.obj.getInsuranceType();
//		Double tax = this.carTypeCost;
//		if(insuranceType==Constant.INSURANCE_PREMIUM) {
//			insuranceCost = tax + (tax*Constant.PREMIUM_PERCENT)/100;
//			return insuranceCost;
//		}
//		else {
//			return tax;
//		}
//	}
//
//	
//	
//}
//old code no more useful
// delete once Completed
//	private double price;
//	public double carTypeCost;
////	private String insuranceType;
//	public Suv(String car_model,String car_type,Double costPrice,String insuranceplan) {
//		setCarModel(car_model);
//		setCarType(car_type);
//		setCarCost(costPrice);
//		setInsuranceType(insuranceplan);
//	}
//	
////	@Override
//	public double carTypeCost() {
//		price = getCarCost();
//		carTypeCost=(price*Constant.SUV_PERCENT)/100;
//		return carTypeCost;
//	}
//	
//	@Override
//	public Double insurance_calculator(Double carTypeCost) {
//		String insuranceType = getInsuranceType();
////		System.out.println("carTypeCost= "+ carTypeCost);
////		System.out.println("insuranceType= "+ insuranceType);
//		
//		if(insuranceType.toLowerCase().equals("premium")) {
//		Double newCost = carTypeCost + (carTypeCost*Constant.PREMIUM_PERCENT)/100;
//		return newCost;
//		}
//		
//		else {
//			return carTypeCost;
//		}
//	}
//}
