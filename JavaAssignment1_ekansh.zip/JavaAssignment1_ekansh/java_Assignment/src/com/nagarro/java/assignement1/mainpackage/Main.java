package com.nagarro.java.assignement1.mainpackage;

import java.util.ArrayList;
import java.util.Scanner;
import com.nagarro.java.assignement1.entities.CarEntities;
import com.nagarro.java.assignement1.entities.CarTypeFactory;
import com.nagarro.java.assignement1.validation.InputValidate;
import com.nagarro.java.assignement1.validation.verify;

public final class Main extends CarTypeFactory {

	public static void main(String[] args) {
		ArrayList<CarEntities> userAllCarData = new ArrayList<>();
		Scanner scanner = new Scanner(System.in);
		char choiceEntry = 'y';
		boolean flag;

		do {
			String carModel;
			System.out.println("A) Enter Car Model");
			do {
				carModel = scanner.nextLine();
				flag = verify.carmodelcheck(carModel);
			} while (flag);

			System.out.println("B) Enter Car Type.\n "
					+ "Press 1 for HatchBack,\n"
					+ " Press 2 for Sedan,\n"
					+ " press 3 for Suv");
			String carType;
			do {
				carType = scanner.nextLine();
				flag = verify.cartypecheck(carType);
			} while (flag);
			
			System.out.println("C) Enter Car Cost in INR ");
			String temp;
			do{
				temp= scanner.nextLine();
				flag=verify.carpricecheck(temp);
			}while(flag);
			
			Double carCost = Double.parseDouble(temp);
			
			System.out.println("D) Enter Car Insurance Type.\n"
					+ " Press 1 for Premium,\n"
					+ " 2 for Basic ");
			String insuranceType;
			do{
				insuranceType= scanner.nextLine();
				flag=verify.insurance_type_check(insuranceType);
			}while(flag);
			
			InputValidate inp_validator = new InputValidate();
			boolean isCorrectInput = inp_validator.inputValidator(carModel, carType, carCost, insuranceType);

			if (isCorrectInput == false) {
				 System.err.println(" Invalid input ");
				System.exit(1);
			} else {
				ArrayList<String> newInput = inp_validator.validator(carModel, carType, carCost, insuranceType);
				String newCarModel = newInput.get(0);
				String newCarType = newInput.get(1);
				Double newCarCost = Double.parseDouble(newInput.get(2));
				String newInsuranceType = newInput.get(3);

				CarTypeFactory obj = new CarTypeFactory();

				CarEntities car_instance = obj.getInstanceOfVehicle(newCarModel, newCarType, newCarCost,
						newInsuranceType);

				double total_cost = car_instance.insurance_calculator();
				System.out.println("Tax for current entry is " + total_cost);
				car_instance.setTotalTax(total_cost);
				userAllCarData.add(car_instance);

				// ask for choice to break loop
				String choice;
				System.out.println("To enter more car details press y and to get total tax amount and exit press n");
				choice = scanner.nextLine();
				choice = choice.toLowerCase();
				choiceEntry = choice.charAt(0);
				System.out.println("\n");
			}
		} while (choiceEntry == 'y');
		scanner.close();

		// to return final tax for all cost
		System.out.println("---------------Total Details Recieved " + userAllCarData.size()+" -----------------\n");
		System.out.println("Fetching Each Deatil Inorder As Entered\n");
		String carObjectModel = "";
		String carObjectType = "";
		String carObjectInsurance = "";
		Double carObjectCost = 0.0;
		Double finalCostForThisUser = 0.0;
		for (CarEntities ce : userAllCarData) {
			carObjectModel = ce.getCarModel();
			carObjectType = ce.getCarType();
			carObjectInsurance = ce.getInsuranceType();
			carObjectCost = ce.getCarCost();
			Double cost = ce.getTotalTax();

			System.out.println("Car Model is " + carObjectModel);
			System.out.println("Car Type is " + carObjectType);
			System.out.println("Car Cost is INR" + carObjectCost);
			System.out.println("Car Insurance Type is " + carObjectInsurance);
			System.out.println("Tax For This Car is " + String.valueOf(cost) + "\n");

			finalCostForThisUser += cost;
		}
		System.out.println("Dear User Total Tax that you need to pay is INR " + String.valueOf(finalCostForThisUser));
		System.exit(0);
	}

}
