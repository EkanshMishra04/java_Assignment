package com.nagarro.java.assignement1.entities;
import com.nagarro.java.assignement1.constants.Constant;

public class Sedan extends CarEntities implements Insurance {
	private Double price;
	private Double carTypeCost;
	private String insuranceType;
	private Double insuranceCost = 0.0;

	public Sedan(String carModel, String carType, Double carCost, String insuranceType) {
		setCarModel(carModel);
		setCarType(carType);
		setCarCost(carCost);
		setInsuranceType(insuranceType);
	}

	@Override
	public Double insurance_calculator() {
		price = getCarCost();
		carTypeCost = (price * Constant.SEDAN_COST_PERCENT)/ 100;
		insuranceType = getInsuranceType();

		if (insuranceType == Constant.INSURANCE_PREMIUM) {
			insuranceCost = carTypeCost + (carTypeCost * Constant.PREMIUM_PERCENT) / 100;
			return insuranceCost;
		} else {
			return carTypeCost;
		}
	}
}


