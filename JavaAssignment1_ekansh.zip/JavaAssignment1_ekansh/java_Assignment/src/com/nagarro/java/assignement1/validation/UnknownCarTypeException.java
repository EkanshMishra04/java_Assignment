package com.nagarro.java.assignement1.validation;
import com.nagarro.java.assignement1.constants.*;

public class UnknownCarTypeException extends Exception {
	public UnknownCarTypeException(String s) {
		super(s);
	}
		
	}

