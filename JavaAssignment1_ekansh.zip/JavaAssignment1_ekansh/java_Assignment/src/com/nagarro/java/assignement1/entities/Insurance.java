package com.nagarro.java.assignement1.entities;

public interface Insurance {
	public abstract Double insurance_calculator();
}
