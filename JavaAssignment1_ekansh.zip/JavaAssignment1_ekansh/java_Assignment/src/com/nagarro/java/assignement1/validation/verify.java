package com.nagarro.java.assignement1.validation;

public class verify {
	public static boolean carmodelcheck(String carModel) {
		if(carModel.equals(""))
		{
			System.err.println("Car Model cannot be empty! Please enter again with right value");
			return true;
		}
		return false;
		
	}

	public static boolean cartypecheck(String carType) {
		Integer carTypeInput;
		try {
		carTypeInput = Integer.parseInt(carType);
		}
		catch(NumberFormatException e) {
			System.err.println("Car Type has to be Integer between 1 and 3. Please enter again with right value");
			return true;
		}
		if(1<=carTypeInput&& carTypeInput<=3)
			return false;
		else
			return true;
	}

	public static boolean carpricecheck(String temp) {
		Double price;
		try {
			price = Double.parseDouble(temp);
		}
		catch(NumberFormatException e) {
			System.err.println("Car Cost must be Double format value");
			return true;
		}
		if(price<=0) {
			System.err.print("Car Cost must be positive!!");
			return true;
		}
		return false;
	}

	public static boolean insurance_type_check(String insuranceType) {
		String Itype = insuranceType;
		Integer premiumType;
		if(Itype.equals("")) {
			System.err.println("Insurance cannot be empty! Please enter again with right value");
			return true;
		}
		try {
			premiumType = Integer.parseInt(insuranceType);
		}
		catch(NumberFormatException e)
		{
			System.err.println("Insurance Scheme must be an Intger between 1 and 2");
			return true;
		}
		if(premiumType==1 || premiumType==2) {
		return false;
		}
		else 
			return true; 

	}
}
