package com.nagarro.java.assignement1.entities;

public abstract class CarEntities implements Insurance{
	// 4 variables private
	// model[year+type+number]
	// car cost [double amount]
	// car type [String Hatchback,sedan,suv]
	// insurance type [String Premium,Basic]	
	//getter and setters for 4 values that we get from user under a method
	// Make different packages- models/entities(getter and setter), 
	
	private String carModel;
	private String carType;
	private Double carCost;
	private String insuranceType;
	private Double totalTax;
	//setters
	public void setCarModel(String modelName) {
		carModel = modelName;
	}
	public void setCarType(String typeName) {
		carType = typeName;
	}
	public void setCarCost(Double costPrice) {
		carCost = costPrice;
	}
	public void setInsuranceType(String insuranceplan) {
		insuranceType = insuranceplan;
	}
	public void setTotalTax(Double value) {
		totalTax = value;
	}
	//getters
	public String getCarModel() {
		return carModel;
	}
	public String getCarType() {
		return carType;
	}
	public Double getCarCost() {
		return carCost;
	}
	public String getInsuranceType() {
		return insuranceType;
	}
	public Double getTotalTax() {
		return totalTax;
	}

}
