package com.nagarro.java.assignement1.validation;

import java.time.LocalTime;
import java.time.LocalDate;
import java.util.ArrayList;
import com.nagarro.java.assignement1.constants.Constant;
import com.nagarro.java.assignement1.validation.UnknownCarTypeException;

public class InputValidate {

	public boolean inputValidator(String carModel, String carType, Double carCost, String insuranceType) {
		Integer carTypeInt = Integer.parseInt(carType);
		Integer insuranceTypeInt = Integer.parseInt(insuranceType);
		if (carModel.isEmpty())
			return false;
		else if (carType.isEmpty())
			return false;
		else if (carCost <= 0)
			return false;
		else if (insuranceType.isEmpty())
			return false;
		else if (carTypeInt != 1 & carTypeInt != 2 && carTypeInt != 3) {
			try {
				throw new UnknownCarTypeException(Constant.UNKNOWN_CAR_TYPE_EXCEPTION);
			} catch (UnknownCarTypeException e) {
				System.out.println("Error " + e.getMessage());
				return false;
			}
		} else if (insuranceTypeInt != 1 && insuranceTypeInt != 2) {
			try {
				throw new UnknownInsuranceTypeException(Constant.UKNOWN_INSURANCE_TYPE_EXCEPTION);
			} catch (UnknownInsuranceTypeException e) {
				System.out.println("Error " + e.getMessage());
				return false;
			}
		}

		return true;
	}

	public ArrayList<String> validator(String carModel, String carType, Double carCost, String insuranceType) {
		ArrayList<String> newInput = new ArrayList<String>();
		boolean isInputCorrect = inputValidator(carModel, carType, carCost, insuranceType);

		if (isInputCorrect) {
			LocalTime time_obj = LocalTime.now();
			LocalDate date_obj = LocalDate.now();
			String newCarModel = carModel + "_" + date_obj.toString() + "_" + time_obj.toString();

			newInput.add(newCarModel);

			String newCarType;
			switch (carType) {
			case "1":
				newCarType = Constant.HATCHBACK;
				newInput.add(newCarType);
				break;

			case "2":
				newCarType = Constant.SEDAN;
				newInput.add(newCarType);
				break;
			case "3":
				newCarType = Constant.SUV;
				newInput.add(newCarType);
				break;
			}
			String newCarCost = carCost.toString();
			newInput.add(newCarCost);
			String newInsuranceType = Constant.INSURANCE_BASIC;
			switch (insuranceType) {
			case "1":
				newInsuranceType = Constant.INSURANCE_PREMIUM;
				break;
			case "2":
				newInsuranceType = Constant.INSURANCE_BASIC;
				break;
			}
			newInput.add(newInsuranceType);

		} else {
			System.out.println("Dear User One Of The Entry Is Invalid. Please Try Again");
			System.exit(1);
		}
		return newInput;
	}
// Uncomment following main method to check functionality of this validation module
//	public static void main(String[] args) {
//		InputValidate test_obj = new InputValidate();
//		ArrayList<String> newInput = test_obj.validator("Swift", "3", 1000000.0, "2");
//		for(String item: newInput) {
//			System.out.println(item);
//		}
//	}
}
