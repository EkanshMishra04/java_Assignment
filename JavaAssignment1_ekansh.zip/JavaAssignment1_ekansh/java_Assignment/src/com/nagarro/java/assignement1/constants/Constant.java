package com.nagarro.java.assignement1.constants;

public class Constant {
	
	public static final Double HATCH_BACK_PERCENT = 5.0;
	public static final Double SEDAN_COST_PERCENT  = 8.0;
	public static final Double SUV_PERCENT  = 10.0;
	public static final Double PREMIUM_PERCENT =20.0;
	public static final String HATCHBACK = "hatchback";
	public static final String SEDAN = "sedan";
	public static final String SUV = "suv";
	public static final String UNKNOWN_CAR_TYPE_EXCEPTION = "Dear User, The Car Type Detail You Entered Was Wrong.";
	public static final String UKNOWN_INSURANCE_TYPE_EXCEPTION = "Dear User, The Premium Detail You Entered Was Wrong";
	public static final String INSURANCE_PREMIUM = "premium";
	public static final String INSURANCE_BASIC = "basic";
	
}
