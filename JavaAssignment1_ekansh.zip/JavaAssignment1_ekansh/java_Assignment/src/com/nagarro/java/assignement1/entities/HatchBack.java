package com.nagarro.java.assignement1.entities;
import com.nagarro.java.assignement1.constants.Constant;
//import com.nagarro.java.assignement1.entities.CarEntities;

public class HatchBack extends CarEntities implements Insurance {
	private Double price;
	public Double carTypeCost;
	private String insuranceType;
	public Double insuranceCost = 0.0;

	public HatchBack(String carModel, String carType, Double carCost, String insuranceType) {
		setCarModel(carModel);
		setCarType(carType);
		setCarCost(carCost);
		setInsuranceType(insuranceType);
	}

	@Override
	public Double insurance_calculator() {
		price = getCarCost();
		carTypeCost = (price * Constant.HATCH_BACK_PERCENT)/100;
		insuranceType = getInsuranceType();

		if (insuranceType == Constant.INSURANCE_PREMIUM) {
			insuranceCost = carTypeCost + (carTypeCost * Constant.PREMIUM_PERCENT) / 100;
			return insuranceCost;
		} else {
			return carTypeCost;
		}
	}
}







//@Override
//public double carTypeCost() {
//	price = getCarCost();
//	carTypeCost = (price*Constant.HATCH_BACK_PERCENT)*100;
//	return carTypeCost;
//}
